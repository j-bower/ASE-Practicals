
#ifndef CONF_H
#define CONF_H

// additional configuration, if any

#endif // CONF_H
