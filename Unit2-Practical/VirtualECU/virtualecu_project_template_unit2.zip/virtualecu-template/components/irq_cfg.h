
#ifndef IRQ_CFG_H
#define IRQ_CFG_H



#endif // IRQ_CFG_H
