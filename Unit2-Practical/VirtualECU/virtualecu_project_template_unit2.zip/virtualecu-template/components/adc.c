
/* Global variables **********************************************************/

/*
 * @brief	ADC0 initialization function
 *
 * @param	void
 * @retval	void
 */
void ADC0_Init(void){
	// nop
}


/*
 * @brief	ADC1 initialization function
 *
 * @param	void
 * @retval	void
 */
void ADC1_Init(void){
	// nop
}


/*
 * @brief	ADC0 conversion start function
 *
 * @param	void
 * @retval	void
 */
void ADC0_StartConversion(void){
	// nop
}


/*
 * @brief	ADC1 conversion start function
 *
 * @param	void
 * @retval	void
 */
void ADC1_StartConversion(void){
	// nop
}

