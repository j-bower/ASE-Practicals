
#ifndef ADC_H_
#define ADC_H_

/* Function prototypes *******************************************************/
void ADC0_Init(void);
void ADC1_Init(void);
void ADC0_StartConversion(void);
void ADC1_StartConversion(void);

#endif /* ADC_H_ */
